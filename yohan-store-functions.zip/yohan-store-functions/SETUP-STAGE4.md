# Yohan Store POS - Stage 4: Notification Sender (Setup Guide)

**Status: written and tested on a fake database. NOT deployed and NOT tested with real phones yet.**
Do not say "notifications work while the app is closed" until you finish Part 6 below.

## What this adds
A small program (a "Cloud Function") that runs on Google's servers. When a product's stock drops
to its alert level, or to 0, it sends a push notification to the phones/computers of **active Admin
and Staff** users. Assistant Staff and deactivated accounts never get it.

Your website files (`app.js`, `index.html`, ...) and your Firestore rules need **no changes** for Stage 4.

## Part 1 - Understand billing BEFORE you start (important)
- Cloud Functions only work on the **Blaze (pay-as-you-go)** plan. Your project is on **Spark** now.
- Blaze needs a billing account with a payment card. You are only charged for usage ABOVE the free amounts.
- Sending push notifications through Firebase Cloud Messaging is free.
- Cloud Functions has a free monthly allowance (about 2 million calls per month, then roughly $0.40 per
  extra million, per recent pricing pages; check the official Firebase pricing page before upgrading).
- A small store with a few hundred sales a month should stay far inside the free allowance. I cannot
  promise your bill will be $0. Deploying also stores a small build image in Google Cloud, which
  can cost a few cents per month on some accounts.
- Blaze has **no automatic spending limit**. So set a **budget alert** (Part 2).
- Safety brakes already in the code: at most 3 copies run at once (`maxInstances: 3`), and the function
  never writes to `products`, so it cannot trigger itself in a loop.
- To stop everything later: `firebase functions:delete sendStockAlerts`, or switch the project back to Spark.
  Your app keeps working; only the automatic alerts stop.

## Part 2 - Upgrade to Blaze and set a budget alert
1. Firebase Console -> bottom-left "Spark / Upgrade" -> follow the steps to Blaze and add your card.
2. Open Google Cloud Console -> Billing -> Budgets & alerts -> Create budget.
   Use a small amount (for example $1 or $5) with email alerts at 50% and 100%.
   (Budgets send emails; they do NOT stop charges by themselves.)

## Part 3 - Install the tools (once)
1. Install Node.js 22 LTS from nodejs.org.
2. Open a terminal (VS Code -> Terminal -> New Terminal) and run:
   `npm install -g firebase-tools`
3. `firebase login`  (a browser opens; use the Google account that owns the Firebase project)

## Part 4 - Put the files in a SEPARATE folder
Make a new folder OUTSIDE your website repo, for example `yohan-store-functions`, and copy in:
`firebase.json`, `.firebaserc`, and the whole `functions` folder.
(Keeping it separate stops GitHub Pages from publishing it. There are no secrets in it either way.)

Then in that folder:
`cd functions`
`npm install`
`npm test`        <- should print "All alert-logic tests passed."

## Part 5 - Set the region, then deploy
1. Find your Firestore location: Firebase Console -> Firestore Database (the location is shown for the
   database), or Project settings -> General -> "Default GCP resource location".
2. Open `functions/index.js` and set `const REGION = "...";` to match.
   Taiwan = `asia-east1` (already set for this project). Singapore = `asia-southeast1`. `nam5` / `us-central` = `us-central1`.
   If unsure, tell me what the console shows and I will give you the exact value.
3. From the folder that contains `firebase.json` run:
   `firebase deploy --only functions`
4. The first deploy may ask to enable several Google APIs (say yes). If it fails with a permissions or
   "Eventarc" message, wait 3-5 minutes and run the same command again. This is common on the first deploy.
5. Success looks like: `Deploy complete!` and `sendStockAlerts` listed under Functions in the console.

## Part 6 - Test (nothing is proven until this passes)
Use two devices if you can: your computer and your phone, both logged in as Admin or Staff with
**Enable Notifications** turned on.
1. Pick a product with, for example, stock 6 and alert level 5.
2. Make real sales (or approve and finalize an Assistant request) until stock drops to 5 or below.
3. Close or minimize the POS tab on the phone. You should get ONE alert: "Low stock: <name>" with the stock number.
4. Sell down to 0: you should get ONE "Out of stock" alert.
5. Edit only the product name or price: you should get NO alert.
6. Log in as Assistant Staff on another device: it should get NO alert.
7. Check the logs: Firebase Console -> Functions -> sendStockAlerts -> Logs (look for "Stock alert sent").
Phone tip: on iPhone, the POS must be added to the Home Screen (iOS 16.4+).

## Notes and limits
- Alerts happen when stock goes DOWN across the alert level. Restocking above the level and selling down again alerts again.
- Expired or invalid device tokens are deleted automatically after a failed send.
- If one phone was used by two logins and someone closed the tab without logging out, the older record
  is cleaned up and the newest login wins. In that rare case an older Admin/Staff record could still
  exist until the next alert. Alerts only contain a product name and stock count, which Assistant Staff can already see.
- The function keeps a tiny record per alert in `notificationEvents` (to avoid double alerts). Clients cannot read
  it (your rules block it). You may delete old ones in the console any time.
