"use strict";

// Decides whether a product update should send an alert.
// It only reacts when STOCK actually crosses a line, so editing a name or
// price (or any other unrelated update) never sends anything.
//
//   "out_of_stock" : stock went from above 0 down to 0
//   "low_stock"    : stock went from above the alert level down to at/below it
//   null           : do nothing
function decideAlert(before, after) {
  if (!before || !after) return null;
  if (after.active === false) return null;                 // archived products stay quiet
  if (!Number.isInteger(before.stock) || !Number.isInteger(after.stock)) return null;
  if (after.stock >= before.stock) return null;            // stock did not go down

  if (before.stock > 0 && after.stock === 0) return "out_of_stock";

  const level = Number.isInteger(after.minStock) ? after.minStock : null;
  if (level !== null && before.stock > level && after.stock <= level) return "low_stock";

  return null;
}

function buildMessage(type, productId, product) {
  const name = String(product.name || productId).slice(0, 80);

  if (type === "out_of_stock") {
    return {
      type,
      title: "Out of stock: " + name,
      body: name + " has 0 left. Time to restock.",
      productId,
      stock: "0",
      tag: "low-stock-" + productId,
      url: "./"
    };
  }

  return {
    type,
    title: "Low stock: " + name,
    body: "Only " + product.stock + " left of " + name + " (alert level " + product.minStock + ").",
    productId,
    stock: String(product.stock),
    tag: "low-stock-" + productId,
    url: "./"
  };
}

// The same token can end up under two users (a shared phone where someone logged out
// without cleanup). Keep ONLY the most recently seen record, so the alert goes to the
// person who last used that device. Returns { keep: [...], stale: [...] }.
function pickDevices(devices) {
  const newest = new Map();
  const stale = [];

  for (const d of devices) {
    const current = newest.get(d.token);
    if (!current) {
      newest.set(d.token, d);
    } else if ((d.lastSeenMs || 0) > (current.lastSeenMs || 0)) {
      stale.push(current);
      newest.set(d.token, d);
    } else {
      stale.push(d);
    }
  }

  return { keep: [...newest.values()], stale };
}

// FCM error codes that mean "this token will never work again".
const DEAD_TOKEN_CODES = new Set([
  "messaging/registration-token-not-registered",
  "messaging/invalid-registration-token"
]);

module.exports = { decideAlert, buildMessage, pickDevices, DEAD_TOKEN_CODES };
