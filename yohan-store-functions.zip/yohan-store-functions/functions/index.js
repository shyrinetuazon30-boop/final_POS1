"use strict";

// Yohan Store POS - trusted notification sender (runs on Google's servers, NOT in the browser).
//
// What it does: when a product's stock drops to its alert level (or to 0), it sends a push
// notification to the devices of ACTIVE Admin and Staff users only.
// No private keys are used: Cloud Functions signs in automatically with the project's
// built-in service account. Nothing secret is stored in this folder.

const { onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { setGlobalOptions } = require("firebase-functions/v2");
const logger = require("firebase-functions/logger");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");
const { decideAlert, buildMessage, pickDevices, DEAD_TOKEN_CODES } = require("./alerts");

// IMPORTANT: set this to the SAME location as your Firestore database
// (Firebase Console -> Firestore Database; see the setup guide).
// Taiwan = "asia-east1" (this project). Singapore = "asia-southeast1". nam5 = "us-central1".
const REGION = "asia-east1";

// maxInstances is a cost safety brake: never run more than 3 copies at once.
setGlobalOptions({ region: REGION, maxInstances: 3 });

initializeApp();
const db = getFirestore();

const NOTIFY_ROLES = ["admin", "staff"];

exports.sendStockAlerts = onDocumentUpdated("products/{productId}", async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  const productId = event.params.productId;

  const type = decideAlert(before, after);
  if (!type) return;   // unrelated update: do nothing (this is the common case)

  // Firestore events can be delivered more than once. The first delivery claims this
  // event id; any repeat sees it already exists and stops (so no double alerts).
  try {
    await db.collection("notificationEvents").doc(event.id).create({
      type,
      productId,
      createdAt: FieldValue.serverTimestamp()
    });
  } catch (error) {
    if (error.code === 6 || /ALREADY_EXISTS/.test(String(error.message))) {
      logger.info("Duplicate event ignored", { eventId: event.id });
      return;
    }
    throw error;
  }

  // Recipients: only ACTIVE users whose role is admin or staff, read fresh from Firestore.
  const usersSnap = await db.collection("users").where("active", "==", true).get();
  const recipients = usersSnap.docs.filter((d) => NOTIFY_ROLES.includes(d.data().role));

  const devices = [];
  for (const user of recipients) {
    const devSnap = await user.ref.collection("devices").get();
    for (const d of devSnap.docs) {
      const info = d.data();
      if (typeof info.token !== "string" || info.token.length < 20) continue;
      devices.push({
        token: info.token,
        ref: d.ref,
        lastSeenMs: info.lastSeenAt && info.lastSeenAt.toMillis ? info.lastSeenAt.toMillis() : 0
      });
    }
  }

  const { keep, stale } = pickDevices(devices);

  // Clean up duplicate records of the same device (shared-phone leftovers).
  await Promise.all(stale.map((d) => d.ref.delete().catch(() => {})));

  if (keep.length === 0) {
    logger.info("No registered devices to notify", { productId, type });
    return;
  }

  // DATA-ONLY message (no "notification" block) so the service worker draws exactly one alert.
  const data = buildMessage(type, productId, after);
  let sent = 0;
  let removed = 0;

  for (let i = 0; i < keep.length; i += 500) {
    const chunk = keep.slice(i, i + 500);
    const response = await getMessaging().sendEachForMulticast({
      tokens: chunk.map((d) => d.token),
      data,
      webpush: { headers: { Urgency: "high", TTL: "86400" } }
    });

    sent += response.successCount;

    // Expired or invalid tokens: delete their records so we stop trying.
    const dead = [];
    response.responses.forEach((result, index) => {
      if (!result.success && result.error && DEAD_TOKEN_CODES.has(result.error.code)) {
        dead.push(chunk[index].ref);
      } else if (!result.success) {
        logger.warn("Send failed", { code: result.error && result.error.code });
      }
    });
    await Promise.all(dead.map((ref) => ref.delete().catch(() => {})));
    removed += dead.length;
  }

  logger.info("Stock alert sent", { productId, type, devices: keep.length, sent, removed });
});
