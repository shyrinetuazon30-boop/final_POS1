"use strict";
const assert = require("assert");
const { decideAlert, buildMessage, pickDevices } = require("./alerts");

const p = (stock, extra = {}) => ({ name: "Biscuits", stock, minStock: 5, ...extra });

// --- when to alert ---
assert.strictEqual(decideAlert(p(8), p(6)), null,        "still above alert level: quiet");
assert.strictEqual(decideAlert(p(6), p(5)), "low_stock", "crosses down to the alert level");
assert.strictEqual(decideAlert(p(6), p(4)), "low_stock", "crosses below the alert level");
assert.strictEqual(decideAlert(p(5), p(4)), null,        "already low: no repeat alert");
assert.strictEqual(decideAlert(p(3), p(0)), "out_of_stock", "low -> zero alerts once as out of stock");
assert.strictEqual(decideAlert(p(10), p(0)), "out_of_stock", "big drop to zero: ONE out-of-stock alert");
assert.strictEqual(decideAlert(p(0), p(0)), null,        "no change");
assert.strictEqual(decideAlert(p(3), p(8)), null,        "restock never alerts");
assert.strictEqual(decideAlert(p(8), { ...p(8), name: "New name", price: 99 }), null, "name/price edit: quiet");
assert.strictEqual(decideAlert(p(6), p(4, { active: false })), null, "archived product: quiet");
assert.strictEqual(decideAlert(p(6), { name: "X", stock: "4", minStock: 5 }), null, "bad data: quiet");
assert.strictEqual(decideAlert(p(6), p(4, { minStock: undefined })), null, "no alert level: quiet");
assert.strictEqual(decideAlert(null, p(1)), null, "missing data: quiet");

// --- message text includes product name and current stock ---
const low = buildMessage("low_stock", "P005", p(3));
assert.strictEqual(low.title, "Low stock: Biscuits");
assert.ok(low.body.includes("3") && low.body.includes("Biscuits"));
assert.strictEqual(low.stock, "3");
assert.strictEqual(low.tag, "low-stock-P005");
for (const v of Object.values(low)) assert.strictEqual(typeof v, "string", "FCM data values must be strings");
const out = buildMessage("out_of_stock", "P005", p(0));
assert.strictEqual(out.title, "Out of stock: Biscuits");
assert.ok(out.body.includes("0"));

// --- duplicate tokens: newest registration wins, older ones are cleaned up ---
const { keep, stale } = pickDevices([
  { token: "T1", uid: "oldAdmin", lastSeenMs: 100 },
  { token: "T2", uid: "staff",    lastSeenMs: 50 },
  { token: "T1", uid: "newStaff", lastSeenMs: 900 }
]);
assert.strictEqual(keep.length, 2);
assert.strictEqual(keep.find((d) => d.token === "T1").uid, "newStaff");
assert.strictEqual(stale.length, 1);
assert.strictEqual(stale[0].uid, "oldAdmin");

console.log("All alert-logic tests passed.");
